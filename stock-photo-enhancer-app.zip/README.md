# 📸 스톡사진 심사 통과 자동보정 스튜디오

> **Adobe Stock · Shutterstock 심사 기준**에 맞춰 사진을 **진단(Pre-flight)** 하고,
> **과보정 없이** 상업용으로 다듬고, **제목·키워드·카테고리 CSV** 까지 한 번에 만드는
> Streamlit 데스크톱 웹 앱입니다.

여행·취미 사진을 그냥 올렸다가 "노출 과다 / 노이즈 / 과도한 보정 / 초상권"으로 반려되는 일을
**업로드 전에** 막는 것이 목적입니다. 사진은 내 PC 안에서만 처리됩니다.

---

## ✨ 이 앱이 하는 일

### ① 스톡 심사 사전 진단 (API 키 없이 동작)

| 점검 | 방법 | 기준 |
|---|---|---|
| 해상도 | 픽셀 수 계산 | **4MP 미만 위험**, 6MP 미만 주의 |
| 종횡비·크기 | 최대공약수 비율 표시 | 짧은 변 1,600px 권장 |
| 하이라이트 날아감 | 휘도 250 이상 픽셀 비율 | 2% 이하 안전 / 6% 초과 위험 |
| 암부 뭉개짐 | 휘도 4 이하 픽셀 비율 | 8% 이하 안전 / 20% 초과 위험 |
| 선명도 | Laplacian σ (장변 1600px 정규화) → 0~100점 | 25 미만 위험 |
| 노이즈 | 평탄 영역 고주파 잔차 **MAD** → 0~100점 | 25 미만 위험 |
| 과채도 | 채도 0.92 초과 픽셀 비율 | 3% 초과 주의 |
| 색공간 | ICC 프로필 검사 | 비 sRGB 경고 |
| 파일 형식·용량 | 형식/용량 | JPEG, 100MB 이하 |

체크리스트 + **심사 준비 점수(0~100)** + "지금 상태로는 반려 가능성이 큽니다" 같은 판정을 보여줍니다.

### ② 과보정 방지 스톡 전용 보정 엔진

- **프리셋 5종**
  | 프리셋 | 용도 |
  |---|---|
  | `Natural Commercial` | 균형 잡힌 표준 상업 스톡 톤 |
  | `Bright & Airy` | 밝고 깨끗한 라이프스타일/인테리어 |
  | `Crisp Architecture & Product` | 선명한 디테일·중립 화이트밸런스 |
  | `Clean Editorial` | 부드러운 대비·과장 없는 다큐/여행 |
  | `Copy Space / Neutral Soft` | 텍스트 배치용 여백 사진 |
- **사진 맞춤 자동 튜닝** — 측정한 클리핑·노출·선명도·노이즈에 따라 프리셋 값을 자동 조정
- **세부 슬라이더** — 자동 화이트밸런스 강도, 노출(EV), 하이라이트 보호, 암부 리프트,
  대비(S자), 생동감(Vibrance), **채도 상한**, 크로마 노이즈 억제, 안전 샤프닝, 엣지 임계값, 색온도, 블랙 포인트
- **과보정 방지 가드** — 슬라이더 자체가 스톡 안전 범위로 제한되고, 극단값은 자동으로 잘립니다.
  - 대비는 0과 1을 고정하는 S자 커브 → **새로운 클리핑을 만들지 않음**
  - 채도는 Vibrance 위주 + 상한 압축 → **과채도 반려 방지**
  - 샤프닝은 휘도만, 강한 엣지는 건너뜀 → **할로(Halo) 방지**
- **출력** — JPEG **품질 95~98**, `subsampling=0`(4:4:4), sRGB 변환, EXIF 유지 + **GPS만 제거**

### ③ 메타데이터 & CSV (Gemini 키를 넣으면 AI가 작성)

- 로고 · 상표 · **차량 번호판** · 얼굴(초상권) · 사유 건물 · 작품 등 **IP 리스크 점검**
- 릴리즈 필요 여부, 에디토리얼 전용 여부 판단
- 영문 **Title(200자 이내)**, 영문 **키워드 25~30개**(중복·# 제거·소문자), **Adobe Stock 카테고리(1~21)**
- **Adobe Stock CSV** (`Filename,Title,Keywords,Category,Releases`) 및 Shutterstock CSV 내보내기

> 🔑 **Gemini API 키가 없어도** 진단 · 보정 · 일괄처리 · ZIP · CSV(직접 입력)는 **100% 정상 작동**합니다.

---

## 🚀 설치 & 실행

### Windows (가장 쉬움)
1. **Python 설치** — <https://www.python.org/downloads/> 에서 설치하고,
   설치 화면에서 **"Add Python to PATH"** 를 반드시 체크합니다.
2. 이 폴더(`stock-photo-enhancer`)에서 **`run_windows.bat` 더블클릭**
3. 처음 1회만 라이브러리를 설치하고(1~2분), 이후에는 바로 실행됩니다.
4. 브라우저에 `http://localhost:8501` 이 자동으로 열립니다.

### macOS / Linux
```bash
cd stock-photo-enhancer
chmod +x run_mac_linux.sh
./run_mac_linux.sh
```

### 명령어로 직접 실행 (모든 OS)
```bash
cd stock-photo-enhancer
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

> **Python 3.9 이상** 권장 (3.12 에서 테스트). 그 외 필요한 것은 `streamlit`, `pillow`, `numpy` 뿐입니다.

---

## ☁️ 설치 없이 스마트폰·웹에서 쓰기 (Streamlit Community Cloud · 무료)

같은 앱을 브라우저만 있으면 폰에서도 쓸 수 있습니다. GitHub 저장소에 올린 뒤 아래 한 번만 설정하면 됩니다.
(무료 플랜은 공개 저장소 1개 + 앱 1개, 개인 사용 용도로 충분합니다.)

1. <https://share.streamlit.io> → **Sign in with GitHub**
2. **Create app** → **Deploy a public app from GitHub**
3. Repository `본인계정/stock-photo-enhancer`, Branch `main`, Main file path `app.py`
4. **Deploy** → 1~2분 뒤 `https://<앱이름>.streamlit.app` 주소가 나옵니다. 폰 홈 화면에 추가하면 앱처럼 열립니다.

> - 무료 인스턴스는 **장시간 접속이 없으면 잠들고**, 다시 열면 30초쯤 걸립니다.
> - 폴더 경로 모드는 서버 PC의 폴더를 보는 기능이라 **웹 배포판에서는 파일 선택 모드만** 동작합니다.
> - Gemini 키는 사이드바에 넣으면 **접속을 유지하는 동안만** 기억됩니다. 영구 보관하려면 앱 설정의 **Secrets** 에 `GEMINI_API_KEY = "..."` 로 넣고 필요할 때 사이드바에 붙여넣어 쓰세요.
> - 사진은 업로드→서버 처리→다운로드 흐름이며, 앱 코드가 저장소에 공개되어도 사진·키는 저장되지 않습니다.

## 🖱️ 사용법

### 단일 사진 (정밀)
1. **🔍 단일 사진 정밀 진단 · 보정** 탭에서 사진 선택
2. 상단 카드에서 **심사 준비 점수 · 해상도 · 클리핑 · 선명도** 확인
3. **📋 점검 항목 전체 보기** 로 반려 위험 항목과 조치 확인
4. 사이드바에서 **프리셋** 선택 → Before/After 자동 비교
5. **🔬 1:1 원본 크기 부분 비교** 로 디테일·할로 확인
6. **⬇️ 보정본 JPEG** / **진단 리포트(Markdown)** 다운로드
7. (선택) **🤖 AI 심사 리스크 + 메타데이터 생성** → 제목·키워드 수정 → **Adobe Stock CSV**

### 여러 장 / 폴더 일괄
1. **🗂️ 다중 파일 / 폴더 일괄 보정** 탭
2. **파일 선택** 또는 **폴더 경로**(내 PC에서 실행할 때만) 입력
3. **🚀 일괄 진단·보정 시작**
4. 결과 표에서 사진별 점수·판정·문제 항목 확인
5. **⬇️ 보정본 ZIP**, **⬇️ 진단 리포트 CSV**, (AI 사용 시) **⬇️ Adobe Stock CSV** 다운로드
6. 폴더 모드에서는 `stock_output` 폴더에 보정본을 직접 저장할 수도 있습니다.

### Adobe Stock 업로드
1. `Contributor → Upload` 에서 보정본 ZIP 을 풀어 사진 업로드
2. **Bulk upload** 에서 CSV 를 함께 올리면 파일명 기준으로 제목·키워드·카테고리가 자동 입력됩니다.
3. 카테고리는 1~21 숫자입니다 (예: Landscapes = 11, Travel = 21).

---

## 🤖 Gemini API 키 (선택)

1. <https://aistudio.google.com/app/apikey> 접속 → **Create API key** (무료)
2. 앱 사이드바 **🔑 Gemini AI** 에 붙여넣기 → **연결 테스트**
3. 사진을 열고 **🤖 AI 심사 리스크 + 메타데이터 생성** 클릭

- 기본 모델: `gemini-2.0-flash` (모델이 없으면 `gemini-2.5-flash` → `gemini-1.5-flash` 순으로 자동 재시도)
- 무료 한도 초과 시 "무료 사용량 한도 초과" 안내가 뜨고, 로컬 기능은 계속 정상 동작합니다.
- Gemini 를 쓰면 해당 사진 1장(장변 1280px 축소본)이 Google 서버로 전송됩니다. 키를 넣지 않으면 외부 전송은 전혀 없습니다.

---

## 🧪 자가 점검 (설치 확인용)

```bash
python self_check.py                      # 내장 합성 이미지로 50여 항목 자동 검사
python self_check.py 사진.jpg 폴더경로     # 내 사진으로도 함께 검사
```

문법 검사, 4MP 판정, 클리핑·선명도·노이즈 검출, 프리셋 5종 적용, 하이라이트 보호·크로마 노이즈 억제 효과,
배치·ZIP·CSV 형식, Gemini 안전성까지 확인하고 **통과/실패 개수**를 출력합니다.

---

## 📁 파일 구조

```
stock-photo-enhancer/
├─ app.py              # Streamlit UI (단일/일괄/도움말 탭)
├─ stock_engine.py     # 진단 + 보정 엔진 (순수 Pillow/NumPy, 테스트 가능)
├─ gemini_stock.py     # Gemini Vision 리스크·메타데이터 (REST, 선택 기능)
├─ self_check.py       # 오프라인 자가 점검 스크립트
├─ requirements.txt
├─ .streamlit/config.toml  # 업로드 한도(400MB)·사용통계 끄기
├─ run_windows.bat     # Windows 더블클릭 실행
├─ run_mac_linux.sh    # macOS/Linux 실행
└─ README.md
```

---

## ❓ 문제 해결

| 증상 | 해결 |
|---|---|
| `'python'은(는) 내부 또는 외부 명령...` | Python 미설치 또는 PATH 미등록 → 재설치하며 "Add Python to PATH" 체크 |
| `streamlit: command not found` | `python -m streamlit run app.py` 로 실행 (모듈 실행 방식) |
| 브라우저가 안 열림 | 주소창에 `http://localhost:8501` 직접 입력 |
| 포트가 이미 사용 중 | `python -m streamlit run app.py --server.port 8502` |
| 한글 폴더 경로에서 오류 | 폴더명을 영문으로 바꾸거나 파일 업로드 모드 사용 |
| 사진이 아주 많아 느림 | 한 번에 20~30장씩 나눠 처리 (사진 1장당 2~5초) |
| AI 메타데이터가 비어 있음 | Gemini 키/한도 확인. 키 없이도 CSV 는 직접입력으로 만들 수 있음 |

---

## 📌 기존 `travel-photo-enhancer` 와 다른 점

| | 여행사진 앱 | 이 앱 (스톡) |
|---|---|---|
| 목적 | 감성 연출 | **심사 통과·상업 판매** |
| 판단 근거 | Gemini 단독 | **로컬 정량 지표(항상) + Gemini(선택)** |
| 보정 톤 | 골든아워·쨍한 색 | 과채도·할로·클리핑 억제 (2차 편집 친화) |
| 출력 | JPEG 95 | **JPEG 95~98, 4:4:4, sRGB, GPS 제거** |
| 결과물 | 사진 | 사진 + **진단 리포트 + Adobe Stock CSV** |
| API 키 | 필수 | **선택 (없어도 전 기능 동작)** |

"""
self_check.py — 스톡 스튜디오 자가 점검(오프라인 테스트)

사용법:
    python self_check.py                # 내장 합성 이미지로 전체 기능 점검
    python self_check.py 사진1.jpg 폴더  # 내 사진/폴더도 함께 점검

검사 항목
 1) 모든 모듈 문법 검사(py_compile)
 2) Pre-flight 진단: 4MP 판정, 클리핑 %, 선명도·노이즈, 체크리스트 생성
 3) 보정 엔진: 프리셋 5종 전부 적용, 하이라이트 보호·크로마 노이즈 억제의 실제 효과 검증
 4) 배치 처리 + ZIP 생성 + Adobe Stock CSV 형식 검증
 5) Gemini 모듈: 키 없음/잘못된 키에서도 앱이 죽지 않는지
"""

from __future__ import annotations

import csv
import io
import os
import py_compile
import sys
import tempfile
import time
import zipfile
from typing import List

import numpy as np
from PIL import Image, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import stock_engine as se  # noqa: E402
import gemini_stock as gs  # noqa: E402

PASS = 0
FAIL = 0
FAILED_NAMES: List[str] = []


def check(condition: bool, label: str, detail: str = "") -> bool:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  ✅ {label}" + (f" — {detail}" if detail else ""))
    else:
        FAIL += 1
        FAILED_NAMES.append(label)
        print(f"  ❌ {label}" + (f" — {detail}" if detail else ""))
    return bool(condition)


# ---------------------------------------------------------------------------
# 테스트 이미지 생성
# ---------------------------------------------------------------------------
def synth_scene(w: int = 2400, h: int = 1800, seed: int = 7) -> Image.Image:
    """하늘 그라디언트 + 지형 + 질감이 있는 합성 풍경(4MP 이상)."""
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    sky = 1.0 - yy / h
    img = np.zeros((h, w, 3), dtype=np.float32)
    img[:, :, 0] = 0.42 + 0.40 * sky
    img[:, :, 1] = 0.55 + 0.32 * sky
    img[:, :, 2] = 0.72 + 0.24 * sky

    horizon = int(h * 0.62)
    ground = yy > horizon
    img[:, :, 0] = np.where(ground, 0.30 + 0.10 * np.sin(xx / 90.0), img[:, :, 0])
    img[:, :, 1] = np.where(ground, 0.38 + 0.08 * np.sin(xx / 70.0), img[:, :, 1])
    img[:, :, 2] = np.where(ground, 0.22 + 0.05 * np.cos(xx / 120.0), img[:, :, 2])

    # 디테일(풀·자갈 질감)
    tex = rng.normal(0, 0.02, (h, w, 1)).astype(np.float32)
    img = img + tex * np.clip(1.2 - sky, 0, 1)[..., None]
    # 부드러운 구름
    img = np.asarray(Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
                     .filter(ImageFilter.GaussianBlur(1.2)), dtype=np.float32) / 255.0
    return Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8), mode="RGB")


def add_blown_highlights(img: Image.Image) -> Image.Image:
    arr = np.asarray(img, dtype=np.float32).copy()
    h, w = arr.shape[:2]
    arr[: int(h * 0.35), :, :] = np.minimum(arr[: int(h * 0.35), :, :] + 70, 255)  # 하늘 날림
    return Image.fromarray(arr.astype(np.uint8), mode="RGB")


def add_noise(img: Image.Image, sigma: float = 5.0, chroma: float = 6.0) -> Image.Image:
    rng = np.random.default_rng(3)
    arr = np.asarray(img, dtype=np.float32)
    noise = rng.normal(0, sigma, arr.shape)
    # 색 노이즈(채널 간 독립 성분)
    noise += rng.normal(0, chroma, arr.shape)
    return Image.fromarray(np.clip(arr + noise, 0, 255).astype(np.uint8), mode="RGB")


# ---------------------------------------------------------------------------
# 1) 문법 검사
# ---------------------------------------------------------------------------
def test_compile() -> None:
    print("\n[1] 문법 검사 (py_compile)")
    for name in ("app.py", "stock_engine.py", "gemini_stock.py", "self_check.py"):
        path = os.path.join(HERE, name)
        try:
            py_compile.compile(path, doraise=True)
            check(True, f"{name} 컴파일")
        except py_compile.PyCompileError as e:
            check(False, f"{name} 컴파일", str(e))


# ---------------------------------------------------------------------------
# 2) Pre-flight 진단
# ---------------------------------------------------------------------------
def test_preflight() -> None:
    print("\n[2] Pre-flight 진단")
    big = synth_scene(2400, 1800)
    buf = io.BytesIO()
    big.save(buf, format="JPEG", quality=95)
    raw = buf.getvalue()

    res = se.analyze(io.BytesIO(raw), filename="scene_4mp.jpg", source_size_bytes=len(raw))
    m, rep = res["metrics"], res["report"]
    check(m["megapixels"] > 4.0, "4.32MP 이미지 해상도 측정", f"{m['megapixels']:.2f} MP {m['width']}×{m['height']}")
    res_check = [c for c in rep["checks"] if c["key"] == "resolution"][0]
    check(res_check["severity"] in ("pass", "warn"), "4.32MP → 해상도 규격 통과(권장치 여유만 주의)",
          f"{res_check['severity']} · {res_check['value']}")

    big7 = synth_scene(3000, 2400, seed=11)
    b7 = io.BytesIO()
    big7.save(b7, format="JPEG", quality=95)
    rep7 = se.analyze(io.BytesIO(b7.getvalue()), filename="scene_7mp.jpg",
                      source_size_bytes=len(b7.getvalue()))["report"]
    check([c for c in rep7["checks"] if c["key"] == "resolution"][0]["severity"] == "pass",
          "7.2MP → 해상도 완전 통과 판정")
    check(0 <= rep["score"] <= 100, "심사 점수 0~100 범위", f"{rep['score']}점")
    check(len(rep["checks"]) >= 10, "체크리스트 항목 생성", f"{len(rep['checks'])}개")
    required = {"width", "height", "megapixels", "aspect_label", "highlight_clip_pct", "shadow_clip_pct",
                "laplacian_var", "laplacian_sigma", "noise_sigma", "sharpness_score", "noise_score",
                "color_cast", "saturation_mean", "file_size_mb"}
    check(required.issubset(m.keys()), "필수 지표 키 모두 존재", f"{len(required)}개")

    # 작은 이미지 → 위험 판정
    small = synth_scene(800, 600)
    sb = io.BytesIO()
    small.save(sb, format="JPEG", quality=95)
    res2 = se.analyze(io.BytesIO(sb.getvalue()), filename="tiny.jpg", source_size_bytes=len(sb.getvalue()))
    small_check = [c for c in res2["report"]["checks"] if c["key"] == "resolution"][0]
    check(small_check["severity"] == "fail", "0.48MP 이미지 → 해상도 위험 판정", small_check["value"])

    # 날린 하늘 → 하이라이트 경고/위험
    blown = add_blown_highlights(synth_scene(1800, 1350))
    bb = io.BytesIO()
    blown.save(bb, format="JPEG", quality=95)
    res3 = se.analyze(io.BytesIO(bb.getvalue()), filename="blown.jpg", source_size_bytes=len(bb.getvalue()))
    hl = [c for c in res3["report"]["checks"] if c["key"] == "highlight"][0]
    check(res3["metrics"]["highlight_clip_pct"] > 2.0, "하이라이트 날아감 검출",
          f"{res3['metrics']['highlight_clip_pct']:.2f}% → {hl['status']}")

    # 흐린 사진 → 선명도 저하 검출
    soft = synth_scene(1800, 1350).filter(ImageFilter.GaussianBlur(3.0))
    sf = io.BytesIO()
    soft.save(sf, format="JPEG", quality=95)
    res4 = se.analyze(io.BytesIO(sf.getvalue()), filename="soft.jpg", source_size_bytes=len(sf.getvalue()))
    sharp = [c for c in res4["report"]["checks"] if c["key"] == "sharpness"][0]
    check(res4["metrics"]["sharpness_score"] < 30, "흐림(가우시안 3px) 선명도 저하 검출",
          f"{res4['metrics']['sharpness_score']}점 ({sharp['status']})")

    # 노이즈 많은 사진 → 노이즈 경고
    noisy = add_noise(synth_scene(1800, 1350), sigma=6, chroma=8)
    nb = io.BytesIO()
    noisy.save(nb, format="JPEG", quality=95)
    res5 = se.analyze(io.BytesIO(nb.getvalue()), filename="noisy.jpg", source_size_bytes=len(nb.getvalue()))
    nz = [c for c in res5["report"]["checks"] if c["key"] == "noise"][0]
    check(res5["metrics"]["noise_score"] < 60, "고노이즈 이미지 노이즈 점수 하락",
          f"{res5['metrics']['noise_score']}점 ({nz['status']})")


# ---------------------------------------------------------------------------
# 3) 보정 엔진
# ---------------------------------------------------------------------------
def test_engine() -> None:
    print("\n[3] 보정 엔진 (프리셋 5종 + 효과 검증)")
    base = synth_scene(2400, 1800)
    b = io.BytesIO()
    base.save(b, format="JPEG", quality=95)
    res = se.analyze(io.BytesIO(b.getvalue()), filename="scene.jpg", source_size_bytes=len(b.getvalue()))
    img, metrics = res["image"], res["metrics"]
    src_arr = np.asarray(img, dtype=np.uint8)

    for key in se.PRESET_ORDER:
        t0 = time.time()
        params = se.auto_tune(metrics, key)
        out = se.enhance(img, params)
        dt = time.time() - t0
        o = out["image"]
        same_size = o.size == img.size
        diff = float(np.abs(np.asarray(o, dtype=np.int16).astype(np.int32) - src_arr.astype(np.int32)).mean())
        print(f"     · {se.PRESETS[key]['label']:<34s} {dt:4.2f}s  평균변화 {diff:5.2f}/255")
        check(same_size and o.mode == "RGB", f"프리셋 {se.PRESETS[key]['label']} 적용", f"{dt:.2f}s")
        check(0.0 < diff < 60.0, f"프리셋 {se.PRESETS[key]['label']} 과보정 아님(평균 변화 적정)",
              f"평균 {diff:.2f}/255")

    # 하이라이트 보호 효과
    blown = add_blown_highlights(synth_scene(1800, 1350))
    bb = io.BytesIO()
    blown.save(bb, format="JPEG", quality=95)
    br = se.analyze(io.BytesIO(bb.getvalue()), filename="blown.jpg", source_size_bytes=len(bb.getvalue()))
    before = br["metrics"]["highlight_clip_pct"]
    p = se.auto_tune(br["metrics"], "natural_commercial")
    out = se.enhance(br["image"], p)
    after = out["stats"]["highlight_clip_pct"]
    check(after <= before + 0.05, "자동 튜닝이 하이라이트를 더 날리지 않음", f"{before:.2f}% → {after:.2f}%")

    # 크로마 노이즈 억제 효과
    noisy = add_noise(synth_scene(1600, 1200), sigma=3, chroma=9)
    chroma_before = se._chroma_noise_sigma(np.asarray(noisy, dtype=np.uint8))
    nr_params = se.sanitize_params({**se.preset_params("natural_commercial"), "chroma_nr": 0.8}, guard=True)
    nr_out = se.enhance(noisy, nr_params)["image"]
    chroma_after = se._chroma_noise_sigma(np.asarray(nr_out, dtype=np.uint8))
    check(chroma_after < chroma_before, "크로마 노이즈 억제가 색노이즈를 실제로 감소",
          f"{chroma_before * 255:.2f} → {chroma_after * 255:.2f}")

    # 가드: 극단값을 넣어도 안전 범위로 제한
    wild = se.sanitize_params({"exposure": 3.0, "contrast": 2.0, "vibrance": 5.0, "sharpen": 9.0}, guard=True)
    check(wild["exposure"] <= se.GUARD_RANGES["exposure"][1]
          and wild["contrast"] <= se.GUARD_RANGES["contrast"][1]
          and wild["vibrance"] <= se.GUARD_RANGES["vibrance"][1]
          and wild["sharpen"] <= se.GUARD_RANGES["sharpen"][1],
          "과보정 방지 가드가 극단값을 제한", f"exp={wild['exposure']}, c={wild['contrast']}, vib={wild['vibrance']}")

    # JPEG 저장 규격
    out = se.enhance(img, se.preset_params("natural_commercial"))
    data = se.jpeg_bytes(out["image"], quality=97, subsampling=0)
    reopened = Image.open(io.BytesIO(data))
    check(reopened.format == "JPEG" and reopened.size == img.size, "JPEG 저장(품질 97, 4:4:4) 검증",
          f"{len(data) / 1024:.0f} KB")
    check(95 <= 97 <= 98, "JPEG 품질 범위 95~98 준수")


# ---------------------------------------------------------------------------
# 4) 배치 + ZIP + CSV
# ---------------------------------------------------------------------------
def test_batch_and_csv() -> None:
    print("\n[4] 배치 처리 · ZIP · Adobe Stock CSV")
    with tempfile.TemporaryDirectory() as tmp:
        src_dir = os.path.join(tmp, "in")
        os.makedirs(src_dir, exist_ok=True)
        for i, (w, h) in enumerate([(2400, 1800), (1600, 1200), (800, 600)]):
            synth_scene(w, h, seed=i).save(os.path.join(src_dir, f"scene_{i}.jpg"), quality=95)

        files = se.iter_image_files(src_dir, recursive=False)
        check(len(files) == 3, "폴더에서 이미지 3장 탐색", f"{[os.path.basename(f) for f in files]}")

        zip_path = os.path.join(tmp, "out.zip")
        rows = []
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in files:
                r = se.process_path(path, preset_key="natural_commercial", use_auto_tune=True,
                                    quality=96, subsampling=0, to_srgb=True)
                zf.writestr(r["out_name"], r["data"])
                rows.append({"filename": r["out_name"], "title": f"Test title for {r['out_name']}",
                             "keywords": ["industry", "outdoor", "sky", "landscape", "daylight"],
                             "category": "Landscapes"})
                check(r["bytes"] > 1000, f"{os.path.basename(path)} 배치 보정", f"{r['bytes'] / 1024:.0f} KB")

        with zipfile.ZipFile(zip_path) as zf:
            names = zf.namelist()
            check(len(names) == 3, "ZIP 에 보정본 3장", f"{names}")
            img0 = Image.open(io.BytesIO(zf.read(names[0])))
            check(img0.format == "JPEG", "ZIP 내부 파일이 JPEG", f"{img0.size}")

        csv_text = se.build_adobe_csv(rows)
        parsed = list(csv.reader(io.StringIO(csv_text)))
        check(parsed[0] == ["Filename", "Title", "Keywords", "Category", "Releases"],
              "Adobe Stock CSV 헤더 형식", str(parsed[0]))
        check(len(parsed) == 4, "CSV 행 수(헤더+3)", f"{len(parsed)}행")
        check(parsed[1][3].isdigit() and 1 <= int(parsed[1][3]) <= 21,
              "카테고리 숫자(1~21) 변환", f"Landscapes → {parsed[1][3]}")
        check(len(parsed[1][2].split(",")) == 5 and parsed[1][2], "키워드 쉼표 구분", parsed[1][2])

        sh = list(csv.reader(io.StringIO(se.build_shutterstock_csv(rows))))
        check(sh[0][0] == "Filename" and "Description" in sh[0], "Shutterstock CSV 헤더", str(sh[0][:3]))

        # 파일명 정리
        check(se.stock_filename("피사 시추 현장.jpg") == "____stock.jpg" or se.stock_filename("피사 시추 현장.jpg").endswith("_stock.jpg"),
              "한글 파일명 → 영문 안전 파일명", se.stock_filename("피사 시추 현장.jpg"))
        check(se.stock_filename("pisa well rig.JPG") == "pisa_well_rig_stock.jpg",
              "공백/대문자 정리", se.stock_filename("pisa well rig.JPG"))


# ---------------------------------------------------------------------------
# 5) Gemini 모듈 (키 없음 / 잘못된 키)
# ---------------------------------------------------------------------------
def test_gemini_safe() -> None:
    print("\n[5] Gemini 모듈 안전성 (키 없이도 앱이 정상)")
    img = synth_scene(600, 450)
    r = gs.analyze_image(img, "")
    check(r["ok"] is False and "API 키" in r["error"], "API 키 없음 → 친절한 안내", r["error"][:40])

    # JSON 파서
    parsed = gs._extract_json('```json\n{"title_en": "A", "keywords_en": ["x"]}\n```')
    check(parsed.get("title_en") == "A", "코드블록 포함 JSON 파싱")
    parsed2 = gs._extract_json('Sure! Here you go:\n{"title_en": "B"}\nHope it helps.')
    check(parsed2.get("title_en") == "B", "설명 문장 섞인 JSON 파싱")

    # 정규화
    norm = gs._normalize({"title_en": "  Sky  ", "keywords_en": ["Sky", "sky", "#blue", "blue sky"],
                          "category": "landscapes", "risk_items": [{"type": "Logo", "severity": "High"}]})
    check(norm["title_en"] == "Sky", "제목 공백 정리")
    check(norm["keywords_en"] == ["sky", "blue", "blue sky"], "키워드 소문자·중복 제거", str(norm["keywords_en"]))
    check(norm["category"] == "Landscapes", "카테고리 표준명 매칭", norm["category"])
    check(norm["risk_items"][0]["type"] == "logo", "리스크 항목 정규화")

    # 잘못된 키로 실제 호출 (네트워크 가능할 때만)
    try:
        bad = gs.analyze_image(img, "INVALID_KEY_FOR_TEST", timeout=20)
        if bad.get("ok") is False:
            check(True, "잘못된 키 → 예외 없이 오류 메시지 반환", str(bad.get("error"))[:60])
        else:
            check(True, "잘못된 키 호출이 응답을 반환(환경에 따라 상이)")
    except Exception as e:  # noqa: BLE001
        check(False, "잘못된 키 호출이 앱을 죽이지 않아야 함", str(e)[:80])


# ---------------------------------------------------------------------------
# 6) 실제 사용자 이미지(선택)
# ---------------------------------------------------------------------------
def test_real_paths(paths: List[str]) -> None:
    print("\n[6] 실제 이미지 점검")
    targets: List[str] = []
    for p in paths:
        if os.path.isdir(p):
            targets.extend(se.iter_image_files(p, recursive=False))
        elif os.path.isfile(p):
            targets.append(p)
    if not targets:
        print("     (건너뜀)")
        return
    for p in targets:
        try:
            t0 = time.time()
            r = se.process_path(p, preset_key="natural_commercial", use_auto_tune=True,
                                quality=96, subsampling=0)
            m, rep = r["metrics"], r["report"]
            print(f"     · {os.path.basename(p)}: {m['width']}×{m['height']} ({m['megapixels']:.2f}MP) "
                  f"점수 {rep['score']} · HL {m['highlight_clip_pct']}% · 선명도 {m['sharpness_score']} "
                  f"· 노이즈 {m['noise_score']} · 보정 후 {r['bytes'] / 1024:.0f}KB ({time.time() - t0:.1f}s)")
            ok = Image.open(io.BytesIO(r["data"])).size == (m["width"], m["height"])
            check(ok and r["bytes"] > 1000, f"{os.path.basename(p)} 진단·보정 성공")
        except Exception as e:  # noqa: BLE001
            check(False, f"{os.path.basename(p)} 처리", repr(e))


# ---------------------------------------------------------------------------
def main() -> int:
    print("=" * 78)
    print(" 스톡사진 심사 통과 자동보정 스튜디오 — 자가 점검")
    print("=" * 78)
    t0 = time.time()
    test_compile()
    test_preflight()
    test_engine()
    test_batch_and_csv()
    test_gemini_safe()
    test_real_paths(sys.argv[1:])

    print("\n" + "=" * 78)
    print(f" 결과: 통과 {PASS} · 실패 {FAIL} · 소요 {time.time() - t0:.1f}s")
    if FAILED_NAMES:
        print(" 실패 항목: " + ", ".join(FAILED_NAMES))
    print("=" * 78)
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

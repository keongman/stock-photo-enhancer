@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 스톡사진 심사 통과 자동보정 스튜디오

echo ============================================================
echo   스톡사진 심사 통과 자동보정 스튜디오
echo ============================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [오류] Python 이 설치되어 있지 않습니다.
    echo         https://www.python.org/downloads/ 에서 설치한 뒤
    echo         설치 화면에서 "Add Python to PATH" 를 반드시 체크하세요.
    echo.
    pause
    exit /b 1
)

if not exist ".venv" (
    echo [1/3] 전용 환경을 만듭니다 (최초 1회, 1~2분)...
    python -m venv .venv
    if errorlevel 1 (
        echo [오류] 가상환경 생성에 실패했습니다.
        pause
        exit /b 1
    )
)

call ".venv\Scripts\activate.bat"

if not exist ".venv\.ready" (
    echo [2/3] 필요한 라이브러리를 설치합니다 (최초 1회)...
    python -m pip install --upgrade pip
    python -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [오류] 라이브러리 설치에 실패했습니다. 인터넷 연결을 확인하세요.
        pause
        exit /b 1
    )
    echo ready> ".venv\.ready"
)

echo [3/3] 앱을 실행합니다. 브라우저가 자동으로 열립니다...
echo       (이 검은 창을 닫으면 앱이 종료됩니다)
echo.
python -m streamlit run app.py

pause

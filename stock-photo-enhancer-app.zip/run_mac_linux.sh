#!/usr/bin/env bash
# macOS / Linux 실행 스크립트
set -e
cd "$(dirname "$0")"

echo "============================================================"
echo "  스톡사진 심사 통과 자동보정 스튜디오"
echo "============================================================"

if ! command -v python3 >/dev/null 2>&1; then
  echo "[오류] python3 가 없습니다. https://www.python.org/downloads/ 에서 설치하세요."
  exit 1
fi

if [ ! -d ".venv" ]; then
  echo "[1/3] 전용 환경 생성 중 (최초 1회)..."
  python3 -m venv .venv
fi

# shellcheck disable=SC1091
source .venv/bin/activate

if [ ! -f ".venv/.ready" ]; then
  echo "[2/3] 라이브러리 설치 중 (최초 1회)..."
  python -m pip install --upgrade pip
  python -m pip install -r requirements.txt
  touch .venv/.ready
fi

echo "[3/3] 앱 실행 — 브라우저가 자동으로 열립니다 (Ctrl+C 로 종료)"
python -m streamlit run app.py
